protoc --proto_path=hyperstart/api/grpc/ --go_out=plugins=grpc:hyperstart/api/grpc/ hyperstart/api/grpc/hyperstart.proto
