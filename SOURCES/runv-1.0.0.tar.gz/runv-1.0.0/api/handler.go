package api

type SandboxHandler interface {
}
