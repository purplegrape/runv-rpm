// +build linux,with_xen

package xen

const (
	REQUIRED_VERSION      = 4005000
	PCI_AVAILABLE_ADDRESS = 3
)
