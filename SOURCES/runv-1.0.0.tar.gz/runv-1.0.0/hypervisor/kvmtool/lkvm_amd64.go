// +build linux,amd64

package kvmtool

func arch_arguments() []string {
	return nil
}
